#include<stdio.h>
int main()
{
printf("Hello, Welcome to the Docker World From IITR ! \n");
return 0;
}
