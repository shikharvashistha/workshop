from time import sleep

# the program will print hello world
#  every 1 second foever
while True:
    print("Hello, World")
    sleep(1)
